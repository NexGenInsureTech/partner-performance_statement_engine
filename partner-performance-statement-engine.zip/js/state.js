// js/state.js (APP STATE – VERY IMPORTANT)

export const state = {
  premiumRaw: [],
  commissionRaw: [],
  columnMap: {},
  snapshots: [],
  statementTill: "",
};
