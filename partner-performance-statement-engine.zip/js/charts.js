// js/charts.js (CANVAS → IMAGE)

export function renderBarChart(labels, data) {
  const c = document.createElement("canvas");
  c.width = 500;
  c.height = 250;
  const ctx = c.getContext("2d");

  const max = Math.max(...data, 1);
  data.forEach((v, i) => {
    const h = (v / max) * 150;
    ctx.fillStyle = "#4F81BD";
    ctx.fillRect(40 + i * 50, 200 - h, 30, h);
    ctx.fillStyle = "#000";
    ctx.fillText(labels[i], 40 + i * 50, 220);
  });

  return c.toDataURL();
}

export function renderLineChart(labels, data) {
  const c = document.createElement("canvas");
  c.width = 500;
  c.height = 250;
  const ctx = c.getContext("2d");

  const valid = data.filter((v) => v != null);
  if (!valid.length) return c.toDataURL();

  const max = Math.max(...valid);
  const min = Math.min(...valid);

  const pad = 40;
  const h = 150;
  const w = 400;

  ctx.beginPath();
  data.forEach((v, i) => {
    if (v == null) return;
    const x = pad + (i / (data.length - 1)) * w;
    const y = pad + h - ((v - min) / (max - min || 1)) * h;
    i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
  });

  ctx.strokeStyle = "#C0504D";
  ctx.lineWidth = 2;
  ctx.stroke();

  labels.forEach((l, i) => {
    ctx.fillText(l, pad + i * (w / labels.length), pad + h + 15);
  });

  return c.toDataURL();
}
